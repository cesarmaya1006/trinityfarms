<?php $__env->startSection('css_Pagina'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo_Pagina'); ?>
<div class="cuerpo">
    <?php if($cantSlider>0): ?>
    <div class="sliderPrincipal">
        <?php $contador = 0; ?>
        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $fotosSlider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotoSlider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $contador = $contador + 1; ?>
                    <?php if($contador<2): ?>
                        <div class="carousel-item active">
                            <img src="<?php echo e(asset('imagenes/slider/'.$fotoSlider->foto)); ?>" class="d-block w-100">
                        </div>
                    <?php else: ?>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('imagenes/slider/'.$fotoSlider->foto)); ?>" class="d-block w-100">
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <?php endif; ?>
    <div class="textoPaginaPrincipal">
        <p align="justify">TRINITY FARMS is a 10 hectare rose farm founded in 1997, which grows and distributes top quality roses to a select
            group of customers in the US, Canada, Europe and Russia. TRINITY is designed to produce roses all year round rather than only in
            peak times for the yearly holidays. Despite this, we remain aware of the need to provide our customers with flowers for holiday
            seasons and we are able to increase a certain amount of our production without discrediting our goal of quality. We strive to
            maintain a select choice of varieties to ensure customer satisfaction.</p>
    </div>
    <br>
    <hr>
    <br>
    <!-- slider noticias1 -->
    <?php if($cantNoticias>0): ?>
    <?php $contador = 0; ?>
    <div class="noticias" id="noticias1">
        <div class="tituloNoticiasHome">
            <h3 class="section-title" style="text-align: center; Color : #0B9746;">NEWS</h3>
        </div>
        <div class="carruselNoticias">
            <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $contador = $contador + 1; ?>
                    <?php if($contador<2): ?>
                        <div class="carousel-item active">
                            <img src="<?php echo e(asset('imagenes/noticias/'.$noticia->foto)); ?>" class="d-block w-100">
                        </div>
                    <?php else: ?>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('imagenes/noticias/'.$noticia->foto)); ?>" class="d-block w-100">
                        </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ingles.plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\trinityfarms\resources\views/ingles/index.blade.php ENDPATH**/ ?>