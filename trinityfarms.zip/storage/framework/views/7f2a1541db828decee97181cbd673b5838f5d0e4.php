<?php $__env->startSection('css_Pagina'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/producto.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo_Pagina'); ?>
<div class="cuerpo">
    <div class="cajonGaleriaInf">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button class="botonFlores" onclick="cambiarFloresGaleria('<?php echo e($producto->id); ?>')">
            <div class="cajaFloresInf1">
                <div class="cajaFloresInf">
                    <img src="<?php echo e(asset('imagenes/productos/'.$producto->foto)); ?>" class="img-fluid">
                </div>
                <div class="estiloRosa2"><?php echo e($producto->nombre); ?></div>
            </div>
        </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="galeriaFlores">
            <div class="cajonGaleria">
                <div class="cajonGaleriaSup">
                    <div class="cajaPrincipalFlores">
                            <div class="fotoPrincipal" id="fotoPrincipal">
                                <div class="tituloGaleriaFlores">
                                    <h2><?php echo e($producto_elegido->nombre); ?></h2>
                                </div>
                                <img src="<?php echo e(asset('imagenes/productos/'.$producto_elegido->foto)); ?>" class="img-fluid">
                            </div>
                            <div class="infoPrincipal" style="border: 1px black solid;">
                                <div class="tablaPrincipal">
                                    <table class="table table-striped">
                                        <tbody id="cuerpoTabla">
                                            <tr>
                                                <th scope="row">COLOR DESCRIPTION</th>
                                                <td><?php echo e($producto_elegido->descripcion); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">STEM LENGTH (CMS)</th>
                                                <td><?php echo e($producto_elegido->stem); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">HEAD SIZE</th>
                                                <td><?php echo e($producto_elegido->head); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">VASE LIFE</th>
                                                <td><?php echo e($producto_elegido->life); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">OPENING SPEED</th>
                                                <td><?php echo e($producto_elegido->opening); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">BLOOM SIZE</th>
                                                <td><?php echo e($producto_elegido->bloom); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">AVAILABLE IN SOLID BOXES</th>
                                                <td><?php echo e($producto_elegido->available); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <input id="fk_rosa" type="text" value="<?php echo e($producto_elegido->id); ?>" style="display: none;">
                                <div class="cajonEmpaques">
                                    <div class="empaqueunico">
                                        <img class="img-fluid" src="<?php echo e(asset('imagenes/sistema/empaque-sin-fondo.png')); ?>">
                                    </div>
                                    <div class="cajaEmpaque">
                                        <div class="estiloRosa1" style="height: 30px;">Quater box</div>
                                        <div class="volumen">Box size: 100 x 28 x 17 cm</div>
                                        <div class="volumen" id="capQuarto">Stems: 5 units</div>
                                    </div>
                                    <div class="cajaEmpaque">
                                        <div class="estiloRosa1" style="height: 30px;">Half box</div>
                                        <div class="volumen">Box size: 100 x 28 x 28 cm</div>
                                        <div class="volumen" id="capTabaco1">Stems: 10 units</div>
                                    </div>
                                    <div class="cajaEmpaque">
                                        <div class="estiloRosa1" style="height: 30px;">Russian half box</div>
                                        <div class="volumen">Box size: 135 x 35 x 35 cm</div>
                                        <div class="volumen" id="capTabaco2">Stems: 20 units</div>
                                    </div>
                                </div>
                                <div class="seleccionadorTallo" style=" display: flex; flex-direction: row; justify-content: space-around; align-items: center; padding: 5px;;border: 1 solid;">
                                    <div class="tituloSub" style="width: 40%;">
                                        STEM LENGTH
                                    </div>
                                    <select class="form-control" id="tam_tallo" onchange="cambiarCajasFlores()" style="width: 40%;">
                                        <option value="40" selected="true">40 cm</option>
                                        <option value="50">50 cm</option>
                                        <option value="60">60 cm</option>
                                        <option value="70">70 cm</option>
                                        <option value="80">80 cm</option>
                                        <option value="90">90 cm</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                </div>
                <br>
                <hr style="width: 100%; height: 1%; background-color: #000;">
                <br>
            </div>
            <div class="cajonInteractivo">
                <div class="cajaInteractiva" id="cajonInteractivo1">
                    <div class="cajaInteractivaImagen" id="cajaInteractivaImagen1"><img id="fotoInteractiva1"class="fluid" src="<?php echo e(asset('imagenes/sistema/flor-interactiva-b-n-1.png')); ?>"></div>
                    <div class="cajaInteractivaImagen" id="cajaInteractivaImagen2"><img id="fotoInteractiva2"class="fluid" src="<?php echo e(asset('imagenes/sistema/flor-interactiva-b-n-2.png')); ?>"></div>
                    <div class="cajaInteractivaImagen" id="cajaInteractivaImagen3"><img id="fotoInteractiva3"class="fluid" src="<?php echo e(asset('imagenes/sistema/flor-interactiva-b-n-1.png')); ?>"></div>
                    <div class="cajaInteractivaImagen" id="cajaInteractivaImagen4"><img id="fotoInteractiva4"class="fluid" src="<?php echo e(asset('imagenes/sistema/flor-interactiva-b-n-2.png')); ?>"></div>
                </div>
                <div class="cajaInteractiva" id="cajonInteractivo2">
                    <div class="triangulo" id="triangulo"></div>
                </div>
                <div class="cajaInteractiva" id="cajonInteractivo3">
                    <div class="textoInteractivo" id="textoInteractivo">Cut stems at least 1” (2.5cm) from bottom.</div>
                </div>
            </div>
            <br>
            <hr style="width: 100%; height: 1%; background-color: #000;">
            <br>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ingles.plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\trinityfarms\resources\views/ingles/producto.blade.php ENDPATH**/ ?>